import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  NotFoundException,
} from '@nestjs/common';
import { TransactionService } from './transaction.service';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { UpdateTransactionDto } from './dto/update-transaction.dto';
import {
  ApiTags,
  ApiResponse,
  ApiOperation,
  ApiParam,
  ApiBody,
} from '@nestjs/swagger';
import { Transaction } from './entities/transaction.entity';

@ApiTags('transaction')
@Controller('transaction')
export class TransactionController {
  constructor(private readonly transactionService: TransactionService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new transaction' })
  @ApiResponse({
    status: 201,
    description: 'The transaction has been successfully created',
    type: Transaction,
  })
  @ApiBody({ type: CreateTransactionDto })
  async create(
    @Body() createTransactionDto: CreateTransactionDto,
  ): Promise<Transaction> {
    try {
      const transaction = await this.transactionService.create(
        createTransactionDto,
      );
      return transaction;
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  @Get()
  @ApiOperation({ summary: 'Get all transactions' })
  @ApiResponse({
    status: 200,
    description: 'Return all transactions',
    type: [Transaction],
  })
  async findAll(): Promise<Transaction[]> {
    try {
      const transactions = await this.transactionService.findAll();
      return transactions;
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a transaction by id' })
  @ApiParam({ name: 'id', type: String, description: 'Transaction id' })
  @ApiResponse({
    status: 200,
    description: 'Return the transaction',
    type: Transaction,
  })
  async findOne(@Param('id') id: string): Promise<Transaction> {
    const transaction = await this.transactionService.findOne(id);
    if (!transaction) {
      throw new NotFoundException(`Transaction with id ${id} not found`);
    }
    return transaction;
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update a transaction by id' })
  @ApiParam({ name: 'id', type: String, description: 'Transaction id' })
  @ApiResponse({
    status: 200,
    description: 'The transaction has been successfully updated',
    type: Transaction,
  })
  async update(
    @Param('id') id: string,
    @Body() updateTransactionDto: UpdateTransactionDto,
  ): Promise<Transaction> {
    try {
      const updatedTransaction = await this.transactionService.update(
        id,
        updateTransactionDto,
      );
      return updatedTransaction;
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a transaction by id' })
  @ApiParam({ name: 'id', type: String, description: 'Transaction id' })
  @ApiResponse({
    status: 200,
    description: 'The transaction has been successfully deleted',
  })
  async remove(@Param('id') id: string): Promise<boolean> {
    try {
      const isDeleted = await this.transactionService.remove(id);
      return isDeleted;
    } catch (error) {
      console.error(error);
      throw error;
    }
  }
}
