import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNumber, IsEnum } from 'class-validator';
import { TransactionType } from '../../enum/transaction.enum';

export class CreateTransactionDto {
  @ApiProperty({ example: '1', description: 'The user ID' })
  @IsString()
  userId: string;

  @ApiProperty({
    example: 'Bitcoin',
    description: 'The name of the cryptocurrency',
  })
  @IsString()
  cryptoName: string;

  @ApiProperty({ example: 0.5, description: 'The amount of the transaction' })
  @IsNumber()
  amount: number;

  @ApiProperty({
    enum: TransactionType,
    description: 'The type of the transaction',
  })
  @IsEnum(TransactionType)
  transactionType: TransactionType;
}
