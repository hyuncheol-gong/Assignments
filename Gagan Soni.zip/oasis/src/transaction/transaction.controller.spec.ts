import { Test, TestingModule } from '@nestjs/testing';
import { TransactionController } from './transaction.controller';
import { TransactionService } from './transaction.service';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { UpdateTransactionDto } from './dto/update-transaction.dto';
import { Transaction } from './entities/transaction.entity';
import { NotFoundException } from '@nestjs/common';
import { TransactionType } from '../enum/transaction.enum';

describe('TransactionController', () => {
  let controller: TransactionController;
  let service: TransactionService;

  const mockTransaction: Transaction = {
    id: '123',
    timestamp: new Date(),
    userId: '456',
    cryptoName: 'Bitcoin',
    amount: 0.5,
    transactionType: TransactionType.PURCHASE,
  };

  const mockCreateTransactionDto: CreateTransactionDto = {
    userId: '456',
    cryptoName: 'Bitcoin',
    amount: 0.5,
    transactionType: TransactionType.PURCHASE,
  };

  const mockUpdateTransactionDto: UpdateTransactionDto = {
    amount: 1,
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TransactionController],
      providers: [
        {
          provide: TransactionService,
          useValue: {
            create: jest.fn().mockResolvedValue(mockTransaction),
            findAll: jest.fn().mockResolvedValue([mockTransaction]),
            findOne: jest.fn().mockResolvedValue(mockTransaction),
            update: jest.fn().mockResolvedValue(mockTransaction),
            remove: jest.fn().mockResolvedValue({ affected: 1 }),
          },
        },
      ],
    }).compile();

    controller = module.get<TransactionController>(TransactionController);
    service = module.get<TransactionService>(TransactionService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('create', () => {
    it('should create a transaction', async () => {
      const result = await controller.create(mockCreateTransactionDto);
      expect(service.create).toHaveBeenCalledWith(mockCreateTransactionDto);
      expect(result).toEqual(mockTransaction);
    });
  });

  describe('findAll', () => {
    it('should return an array of transactions', async () => {
      const result = await controller.findAll();
      expect(service.findAll).toHaveBeenCalled();
      expect(result).toEqual([mockTransaction]);
    });
  });

  describe('findOne', () => {
    it('should return a transaction by id', async () => {
      const result = await controller.findOne(mockTransaction.id);
      expect(service.findOne).toHaveBeenCalledWith(mockTransaction.id);
      expect(result).toEqual(mockTransaction);
    });

    it('should throw NotFoundException when transaction is not found', async () => {
      jest.spyOn(service, 'findOne').mockResolvedValueOnce(null);
      await expect(controller.findOne(mockTransaction.id)).rejects.toThrow(
        NotFoundException,
      );
    });
  });

  describe('update', () => {
    it('should update a transaction by id', async () => {
      const result = await controller.update(
        mockTransaction.id,
        mockUpdateTransactionDto,
      );
      expect(service.update).toHaveBeenCalledWith(
        mockTransaction.id,
        mockUpdateTransactionDto,
      );
      expect(result).toEqual(mockTransaction);
    });
  });

  describe('remove', () => {
    it('should remove a transaction by id', async () => {
      const result = await controller.remove(mockTransaction.id);
      expect(service.remove).toHaveBeenCalledWith(mockTransaction.id);
      expect(result).toEqual({ affected: 1 });
    });
  });
});
