import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { UpdateTransactionDto } from './dto/update-transaction.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { FindOneOptions, Repository } from 'typeorm';
import { Transaction } from './entities/transaction.entity';

@Injectable()
export class TransactionService {
  constructor(
    @InjectRepository(Transaction)
    private transactionRepository: Repository<Transaction>,
  ) {}

  async create(
    createTransactionDto: CreateTransactionDto,
  ): Promise<Transaction> {
    const transaction = await this.transactionRepository.save(
      createTransactionDto,
    );
    return transaction;
  }

  async findAll(): Promise<Transaction[]> {
    const transactions = await this.transactionRepository.find();
    return transactions;
  }

  async findOne(id: string): Promise<Transaction> {
    const options: FindOneOptions<Transaction> = { where: { id } };
    const transaction = await this.transactionRepository.findOne(options);

    if (!transaction) {
      throw new NotFoundException(`Transaction with id ${id} not found`);
    }

    return transaction;
  }

  async update(
    id: string,
    updateTransactionDto: UpdateTransactionDto,
  ): Promise<Transaction> {
    const transaction = await this.findOne(id);

    Object.assign(transaction, updateTransactionDto);

    const updatedTransaction = await this.transactionRepository.save(
      transaction,
    );
    return updatedTransaction;
  }

  async remove(id: string): Promise<boolean> {
    try {
      const transaction = await this.findOne(id);
      await this.transactionRepository.remove(transaction);
      return true;
    } catch (error) {
      console.error(error);
      throw new Error(`Failed to delete transaction with id ${id}`);
    }
  }
}
