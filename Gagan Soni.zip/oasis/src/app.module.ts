import { Module } from '@nestjs/common';
import { TransactionModule } from './transaction/transaction.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { Transaction } from './transaction/entities/transaction.entity';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'gagansoni',
      password: 'root',
      database: 'oasis',
      autoLoadEntities: true,
      logging: true,
      entities: [Transaction],
      synchronize: true,
    }),
    TransactionModule,
  ],
})
export class AppModule {
  constructor(private dataSource: DataSource) {}
}
