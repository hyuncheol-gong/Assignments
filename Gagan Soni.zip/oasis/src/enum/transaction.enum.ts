export enum TransactionType {
  PURCHASE = 'purchase',
  SELL = 'sell',
}
