import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { MicroserviceOptions, Transport } from '@nestjs/microservices';
import { join } from 'path';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Create a gRPC microservice
  const microserviceOptions: MicroserviceOptions = {
    transport: Transport.GRPC,
    options: {
      url: 'localhost:5000',
      package: 'transaction',
      protoPath: join(__dirname, '../src/transaction/proto/transaction.proto'),
    },
  };
  app.connectMicroservice<MicroserviceOptions>(microserviceOptions);

  // Start the gRPC microservice
  await app.startAllMicroservices();

  const config = new DocumentBuilder()
    .setTitle('Oasis API')
    .setDescription('The Oasis API description')
    .setVersion('1.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, document);

  await app.listen(3000);
}
bootstrap();
