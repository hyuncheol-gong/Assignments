This is hybrid app with http and grpc

http port: 3001
grpc port: 3000

Swagger UI:

http://localhost:3001/api-docs


Run the app

```
npm ci
docker-compose up -d
npm run main:dev
```

