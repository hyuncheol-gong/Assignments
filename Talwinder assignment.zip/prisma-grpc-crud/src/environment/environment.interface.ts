export interface EnvironmentInterface {
  databaseUrl: string;
  httpPort: number;
  grpcPort: number;
}
