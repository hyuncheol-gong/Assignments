import * as dotenv from 'dotenv';
import ProcessEnv = NodeJS.ProcessEnv;
import { EnvironmentInterface } from './environment.interface';

dotenv.config();
const env: ProcessEnv = process.env;

export const environment: EnvironmentInterface = {
  databaseUrl: env.DATABASE_URL,
  httpPort: parseInt(env.HTTP_PORT),
  grpcPort: parseInt(env.GRPC_PORT),
}
