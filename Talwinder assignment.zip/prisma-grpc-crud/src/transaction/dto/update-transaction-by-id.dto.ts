import { UpdateTransactionDto } from './update-transaction.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class UpdateTransactionByIdDto extends UpdateTransactionDto { 
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  public id: number;
}
