import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class TransactionByIdDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  public id: number;
}
