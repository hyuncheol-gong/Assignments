import { ApiProperty } from '@nestjs/swagger';
import { Transaction, TransactionType } from '@prisma/client';
import { IsNotEmpty, IsNumber, IsString, IsEnum } from 'class-validator';

export class CreateTransactionDto implements Partial<Transaction> {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  public user_id: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @IsEnum(TransactionType)
  public transaction_type: TransactionType;

  @ApiProperty()
  @IsNumber()
  public amount: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  public crypto_name: string;
}
