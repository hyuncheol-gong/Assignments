import {
  Controller,
  BadRequestException,
  UseFilters,
  UsePipes,
  ValidationPipe,
  NotFoundException,
  Injectable,
  PipeTransform,
} from '@nestjs/common';
import { Transaction, Transaction as TransactionModel } from '@prisma/client';
import { TransactionService } from '../../services/transaction.service';
import { GrpcMethod } from '@nestjs/microservices';
import { ExceptionFilter } from 'src/common';
import { TransactionByIdDto, UpdateTransactionByIdDto, CreateTransactionDto } from 'src/transaction/dto';

@Injectable()
export class CamelToSnakeCase implements PipeTransform<any> {
  async transform(payload: any) {
    const camelToSnakeCase = str => str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
    const newPayload = {};

    for (const [key, value] of Object.entries(payload)) {
      newPayload[camelToSnakeCase(key)] = value;
    }

    return newPayload;
  }
}

@Controller()
@UsePipes(new CamelToSnakeCase(), new ValidationPipe({ transform: true }))
@UseFilters(new ExceptionFilter())
export class GrpcTransactionController {
  constructor(
    private readonly transactionService: TransactionService,
  ) { }

  @GrpcMethod('TransactionService')
  async findById(data: TransactionByIdDto): Promise<Transaction> {
    const transaction: Transaction = await this.transactionService.transaction({ id: Number(data.id) });

    if (!transaction) {
      throw new NotFoundException('Transaction not found!');
    }

    return transaction;
  }

  @GrpcMethod('TransactionService')
  async deleteById(data: TransactionByIdDto): Promise<Boolean> {
    const transaction: Transaction = await this.transactionService.transaction({ id: Number(data.id) });

    if (!transaction) {
      throw new NotFoundException('Transaction not found!');
    }

    return !!(await this.transactionService.deleteTransaction({ id: Number(data.id) }));
  }

  @GrpcMethod('TransactionService')
  async create(data: CreateTransactionDto): Promise<Transaction> {
    console.log(data)
    return this.transactionService.createTransaction({
      ...data,
    });
  }

  @GrpcMethod('TransactionService')
  async update(data: UpdateTransactionByIdDto): Promise<Transaction> {
    const id: number = data.id;
    delete data.id;
    const transaction: TransactionModel = await this.transactionService.transaction({ id: Number(id) });

    console.log('update', data)
    if (!transaction) {
      throw new BadRequestException('Given transaction not found');
    }


    return this.transactionService.updateTransaction({
      where: { id: Number(id) },
      data: { ...data },
    });
  }
}
