import {
  Controller,
  Get,
  Param,
  Post,
  Body,
  Put,
  Delete,
  BadRequestException,
} from '@nestjs/common';
import { Transaction as TransactionModel } from '@prisma/client';
import { TransactionService } from '../../services';
import { CreateTransactionDto, UpdateTransactionDto } from '../../dto';

@Controller('transaction')
export class HttpTransactionController {
  constructor(
    private readonly transactionService: TransactionService,
  ) { }

  @Get(':id')
  async findById(@Param('id') id: string): Promise<TransactionModel> {
    return this.transactionService.transaction({ id: Number(id) });
  }

  @Post()
  async create(
    @Body() createData: CreateTransactionDto,
  ): Promise<TransactionModel> {
    return this.transactionService.createTransaction({
      ...createData,
    });
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() updateData: UpdateTransactionDto,
  ): Promise<TransactionModel> {
    const transaction: TransactionModel = await this.transactionService.transaction({ id: Number(id) });

    if (!transaction) {
      throw new BadRequestException('Given transaction not found');
    }

    return this.transactionService.updateTransaction({
      where: { id: Number(id) },
      data: { ...updateData },
    });
  }

  @Delete(':id')
  async deleteById(@Param('id') id: string): Promise<Boolean> {
    const transaction: TransactionModel = await this.transactionService.transaction({ id: Number(id) });

    if (!transaction) {
      throw new BadRequestException('Given transaction not found');
    }

    return !!(await this.transactionService.deleteTransaction({ id: Number(id) }));
  }
}