import { Module } from '@nestjs/common';
import { ClientsModule } from '@nestjs/microservices';
import { TransactionService } from './services/transaction.service';
import { PrismaModule } from 'src/prisma/prisma.module';
import { HttpTransactionController } from './controllers/http';
import { GrpcTransactionController } from './controllers/grpc';
import { grpcClientOptions } from './grpc-client.option';

@Module({
  providers: [TransactionService],
  controllers: [GrpcTransactionController, HttpTransactionController],
  imports: [
    PrismaModule,
    ClientsModule.register([
      {
        name: 'transaction',
        ...grpcClientOptions,
      },
    ]),
  ],
})
export class TransactionModule {}
